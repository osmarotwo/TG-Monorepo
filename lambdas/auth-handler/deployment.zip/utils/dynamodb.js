"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EMAIL_VERIFICATIONS_TABLE = exports.SESSIONS_TABLE = exports.USERS_TABLE = exports.docClient = void 0;
exports.createUser = createUser;
exports.getUserById = getUserById;
exports.getUserByEmail = getUserByEmail;
exports.getUserByGoogleId = getUserByGoogleId;
exports.updateUser = updateUser;
exports.createSession = createSession;
exports.getSession = getSession;
exports.invalidateSession = invalidateSession;
exports.createEmailVerification = createEmailVerification;
exports.getEmailVerification = getEmailVerification;
exports.deleteEmailVerification = deleteEmailVerification;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
// Initialize DynamoDB client
const dynamoClient = new client_dynamodb_1.DynamoDBClient({});
exports.docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
// Table names from environment variables
exports.USERS_TABLE = process.env.USERS_TABLE;
exports.SESSIONS_TABLE = process.env.SESSIONS_TABLE;
exports.EMAIL_VERIFICATIONS_TABLE = process.env.EMAIL_VERIFICATIONS_TABLE;
/**
 * Create a new user
 */
async function createUser(userData) {
    const user = {
        PK: `USER#${userData.userId}`,
        SK: 'PROFILE',
        GSI1PK: `EMAIL#${userData.email}`,
        GSI1SK: 'USER',
        ...userData,
    };
    // Add Google GSI if googleId exists
    if (userData.googleId) {
        user.GSI2PK = `GOOGLE#${userData.googleId}`;
        user.GSI2SK = 'USER';
    }
    try {
        await exports.docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: exports.USERS_TABLE,
            Item: user,
            ConditionExpression: 'attribute_not_exists(PK)', // Prevent duplicates
        }));
        return user;
    }
    catch (error) {
        if (error.name === 'ConditionalCheckFailedException') {
            throw new Error('User already exists');
        }
        throw error;
    }
}
/**
 * Get user by ID
 */
async function getUserById(userId) {
    try {
        const response = await exports.docClient.send(new lib_dynamodb_1.GetCommand({
            TableName: exports.USERS_TABLE,
            Key: {
                PK: `USER#${userId}`,
                SK: 'PROFILE',
            },
        }));
        return response.Item || null;
    }
    catch (error) {
        console.error('Error getting user by ID:', error);
        throw new Error('Failed to get user');
    }
}
/**
 * Get user by email
 */
async function getUserByEmail(email) {
    try {
        const response = await exports.docClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: exports.USERS_TABLE,
            IndexName: 'GSI1',
            KeyConditionExpression: 'GSI1PK = :email AND GSI1SK = :sk',
            ExpressionAttributeValues: {
                ':email': `EMAIL#${email}`,
                ':sk': 'USER',
            },
        }));
        const items = response.Items;
        return items && items.length > 0 ? items[0] : null;
    }
    catch (error) {
        console.error('Error getting user by email:', error);
        throw new Error('Failed to get user');
    }
}
/**
 * Get user by Google ID
 */
async function getUserByGoogleId(googleId) {
    try {
        const response = await exports.docClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: exports.USERS_TABLE,
            IndexName: 'GSI2',
            KeyConditionExpression: 'GSI2PK = :googleId AND GSI2SK = :sk',
            ExpressionAttributeValues: {
                ':googleId': `GOOGLE#${googleId}`,
                ':sk': 'USER',
            },
        }));
        const items = response.Items;
        return items && items.length > 0 ? items[0] : null;
    }
    catch (error) {
        console.error('Error getting user by Google ID:', error);
        throw new Error('Failed to get user');
    }
}
/**
 * Update user profile
 */
async function updateUser(userId, updates) {
    const updateExpressions = [];
    const expressionAttributeNames = {};
    const expressionAttributeValues = {};
    // Build update expression dynamically
    Object.entries(updates).forEach(([key, value]) => {
        if (key !== 'PK' && key !== 'SK' && key !== 'userId' && value !== undefined) {
            updateExpressions.push(`#${key} = :${key}`);
            expressionAttributeNames[`#${key}`] = key;
            expressionAttributeValues[`:${key}`] = value;
        }
    });
    // Always update updatedAt
    updateExpressions.push('#updatedAt = :updatedAt');
    expressionAttributeNames['#updatedAt'] = 'updatedAt';
    expressionAttributeValues[':updatedAt'] = new Date().toISOString();
    try {
        const response = await exports.docClient.send(new lib_dynamodb_1.UpdateCommand({
            TableName: exports.USERS_TABLE,
            Key: {
                PK: `USER#${userId}`,
                SK: 'PROFILE',
            },
            UpdateExpression: `SET ${updateExpressions.join(', ')}`,
            ExpressionAttributeNames: expressionAttributeNames,
            ExpressionAttributeValues: expressionAttributeValues,
            ReturnValues: 'ALL_NEW',
        }));
        return response.Attributes;
    }
    catch (error) {
        console.error('Error updating user:', error);
        throw new Error('Failed to update user');
    }
}
/**
 * Create a session
 */
async function createSession(sessionData) {
    const session = {
        PK: `SESSION#${sessionData.sessionId}`,
        SK: 'SESSION',
        ...sessionData,
        isActive: true, // Sesión activa por defecto
        // Agregar TTL en segundos (expiresAt está en milisegundos)
        ttl: Math.floor(sessionData.expiresAt / 1000),
    };
    console.log('Creating session:', {
        sessionId: sessionData.sessionId,
        userId: sessionData.userId,
        expiresAt: new Date(sessionData.expiresAt).toISOString(),
        ttl: session.ttl
    });
    try {
        await exports.docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: exports.SESSIONS_TABLE, // Corregido: usar la tabla correcta
            Item: session,
        }));
        console.log('Session created successfully');
        return session;
    }
    catch (error) {
        console.error('Error creating session:', error);
        throw new Error('Failed to create session');
    }
}
/**
 * Get session by ID
 */
async function getSession(sessionId) {
    try {
        const response = await exports.docClient.send(new lib_dynamodb_1.GetCommand({
            TableName: exports.SESSIONS_TABLE,
            Key: {
                PK: `SESSION#${sessionId}`,
                SK: 'SESSION', // Corregido: usar el SK correcto
            },
        }));
        return response.Item || null;
    }
    catch (error) {
        console.error('Error getting session:', error);
        throw new Error('Failed to get session');
    }
}
/**
 * Invalidate session
 */
async function invalidateSession(sessionId) {
    try {
        await exports.docClient.send(new lib_dynamodb_1.UpdateCommand({
            TableName: exports.SESSIONS_TABLE,
            Key: {
                PK: `SESSION#${sessionId}`,
                SK: 'TOKEN',
            },
            UpdateExpression: 'SET isActive = :inactive',
            ExpressionAttributeValues: {
                ':inactive': false,
            },
        }));
    }
    catch (error) {
        console.error('Error invalidating session:', error);
        throw new Error('Failed to invalidate session');
    }
}
/**
 * Create email verification
 */
async function createEmailVerification(verificationData) {
    const verification = {
        PK: `EMAIL_VERIFY#${verificationData.token}`,
        SK: 'TOKEN',
        ...verificationData,
        // Agregar TTL en segundos (expiresAt está en milisegundos)
        ttl: Math.floor(verificationData.expiresAt / 1000),
    };
    console.log('Creating email verification:', {
        token: verificationData.token,
        email: verificationData.email,
        userId: verificationData.userId,
        expiresAt: new Date(verificationData.expiresAt).toISOString(),
        ttl: verification.ttl
    });
    try {
        await exports.docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: exports.EMAIL_VERIFICATIONS_TABLE,
            Item: verification,
        }));
        console.log('Email verification created successfully');
        return verification;
    }
    catch (error) {
        console.error('Error creating email verification:', error);
        throw new Error('Failed to create email verification');
    }
}
/**
 * Get email verification by token
 */
async function getEmailVerification(token) {
    try {
        const response = await exports.docClient.send(new lib_dynamodb_1.GetCommand({
            TableName: exports.EMAIL_VERIFICATIONS_TABLE,
            Key: {
                PK: `EMAIL_VERIFY#${token}`,
                SK: 'TOKEN',
            },
        }));
        return response.Item || null;
    }
    catch (error) {
        console.error('Error getting email verification:', error);
        throw new Error('Failed to get email verification');
    }
}
/**
 * Delete email verification
 */
async function deleteEmailVerification(token) {
    try {
        await exports.docClient.send(new lib_dynamodb_1.DeleteCommand({
            TableName: exports.EMAIL_VERIFICATIONS_TABLE,
            Key: {
                PK: `EMAIL_VERIFY#${token}`,
                SK: 'TOKEN',
            },
        }));
    }
    catch (error) {
        console.error('Error deleting email verification:', error);
        throw new Error('Failed to delete email verification');
    }
}
//# sourceMappingURL=dynamodb.js.map