import { DynamoDBDocumentClient } from '@aws-sdk/lib-dynamodb';
export declare const docClient: DynamoDBDocumentClient;
export declare const USERS_TABLE: string;
export declare const SESSIONS_TABLE: string;
export declare const EMAIL_VERIFICATIONS_TABLE: string;
export interface User {
    PK: string;
    SK: string;
    GSI1PK: string;
    GSI1SK: string;
    GSI2PK?: string;
    GSI2SK?: string;
    userId: string;
    googleId?: string;
    email: string;
    firstName?: string;
    lastName?: string;
    fullName?: string;
    name?: string;
    pictureUrl?: string;
    phone?: string;
    birthDate?: string;
    gender?: 'male' | 'female' | 'prefer-not-to-say';
    password?: string;
    passwordHash?: string;
    emailVerified: boolean;
    profileCompleted: boolean;
    provider: 'google' | 'email';
    registrationMethod?: 'google' | 'manual';
    accountStatus?: 'pending' | 'active';
    role?: string;
    createdAt: string;
    updatedAt: string;
}
export interface Session {
    PK: string;
    SK: string;
    sessionId: string;
    userId: string;
    refreshToken: string;
    expiresAt: number;
    isActive?: boolean;
    ttl?: number;
}
export interface EmailVerification {
    PK: string;
    SK: string;
    userId: string;
    email: string;
    token: string;
    expiresAt: number;
    createdAt?: string;
    ttl?: number;
}
/**
 * Create a new user
 */
export declare function createUser(userData: Omit<User, 'PK' | 'SK' | 'GSI1PK' | 'GSI1SK' | 'GSI2PK' | 'GSI2SK'>): Promise<User>;
/**
 * Get user by ID
 */
export declare function getUserById(userId: string): Promise<User | null>;
/**
 * Get user by email
 */
export declare function getUserByEmail(email: string): Promise<User | null>;
/**
 * Get user by Google ID
 */
export declare function getUserByGoogleId(googleId: string): Promise<User | null>;
/**
 * Update user profile
 */
export declare function updateUser(userId: string, updates: Partial<User>): Promise<User>;
/**
 * Create a session
 */
export declare function createSession(sessionData: Omit<Session, 'PK' | 'SK'>): Promise<Session>;
/**
 * Get session by ID
 */
export declare function getSession(sessionId: string): Promise<Session | null>;
/**
 * Invalidate session
 */
export declare function invalidateSession(sessionId: string): Promise<void>;
/**
 * Create email verification
 */
export declare function createEmailVerification(verificationData: Omit<EmailVerification, 'PK' | 'SK'>): Promise<EmailVerification>;
/**
 * Get email verification by token
 */
export declare function getEmailVerification(token: string): Promise<EmailVerification | null>;
/**
 * Delete email verification
 */
export declare function deleteEmailVerification(token: string): Promise<void>;
//# sourceMappingURL=dynamodb.d.ts.map