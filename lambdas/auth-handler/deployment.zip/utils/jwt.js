"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyPasswordResetToken = exports.generatePasswordResetToken = void 0;
exports.generateTokens = generateTokens;
exports.verifyToken = verifyToken;
exports.generateResetToken = generateResetToken;
exports.verifyResetToken = verifyResetToken;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const client_ssm_1 = require("@aws-sdk/client-ssm");
const ssmClient = new client_ssm_1.SSMClient({});
// Cache for JWT secret
let jwtSecretCache = null;
let cacheExpiry = 0;
/**
 * Get JWT Secret from SSM Parameter Store with caching
 */
async function getJWTSecret() {
    const now = Date.now();
    if (jwtSecretCache && now < cacheExpiry) {
        return jwtSecretCache;
    }
    try {
        const command = new client_ssm_1.GetParameterCommand({
            Name: '/auth/jwt-secret',
            WithDecryption: true,
        });
        const response = await ssmClient.send(command);
        if (!response.Parameter?.Value) {
            throw new Error('JWT secret not found in SSM');
        }
        jwtSecretCache = response.Parameter.Value;
        cacheExpiry = now + (10 * 60 * 1000); // Cache for 10 minutes
        return jwtSecretCache;
    }
    catch (error) {
        console.error('Error getting JWT secret from SSM:', error);
        throw new Error('Failed to retrieve JWT secret');
    }
}
/**
 * Generate access token and refresh token
 */
async function generateTokens(userId, email, sessionId) {
    const secret = await getJWTSecret();
    const finalSessionId = sessionId || Date.now().toString();
    const payload = {
        userId,
        email: email || '',
        role: 'user',
        sessionId: finalSessionId
    };
    const accessTokenExpiry = process.env.TOKEN_EXPIRY || '1h';
    const refreshTokenExpiry = process.env.REFRESH_TOKEN_EXPIRY || '30d';
    // Generate access token
    const accessToken = jsonwebtoken_1.default.sign(payload, secret, {
        expiresIn: accessTokenExpiry,
    });
    // Generate refresh token (longer expiry, minimal payload)
    const refreshToken = jsonwebtoken_1.default.sign({
        userId: payload.userId,
        sessionId: payload.sessionId,
        email: payload.email,
        type: 'refresh'
    }, secret, {
        expiresIn: refreshTokenExpiry,
    });
    // Calculate expiry time in seconds
    const expiresIn = jsonwebtoken_1.default.decode(accessToken);
    const expirationTime = expiresIn?.exp ? expiresIn.exp - expiresIn.iat : 3600;
    return {
        accessToken,
        refreshToken,
        expiresIn: expirationTime,
    };
}
/**
 * Verify and decode JWT token
 */
async function verifyToken(token, type = 'access') {
    const secret = await getJWTSecret();
    try {
        const decoded = jsonwebtoken_1.default.verify(token, secret, {
            issuer: 'auth-service',
            audience: type === 'access' ? 'api-service' : 'api-service',
        });
        return decoded;
    }
    catch (error) {
        throw new Error('Invalid token');
    }
}
// Alias para compatibilidad
exports.generatePasswordResetToken = generateResetToken;
exports.verifyPasswordResetToken = verifyResetToken;
/**
 * Generate password reset token
 */
async function generateResetToken(userId, email) {
    const secret = await getJWTSecret();
    return jsonwebtoken_1.default.sign({
        userId,
        email,
        type: 'password-reset'
    }, secret, {
        expiresIn: '1h', // Reset tokens expire in 1 hour
        issuer: 'auth-service',
        audience: 'password-reset',
    });
}
/**
 * Verify password reset token
 */
async function verifyResetToken(token) {
    const secret = await getJWTSecret();
    try {
        const decoded = jsonwebtoken_1.default.verify(token, secret, {
            issuer: 'auth-service',
            audience: 'password-reset',
        });
        if (decoded.type !== 'password-reset') {
            throw new Error('Invalid token type');
        }
        return {
            userId: decoded.userId,
            email: decoded.email,
        };
    }
    catch (error) {
        throw new Error('Invalid or expired reset token');
    }
}
//# sourceMappingURL=jwt.js.map