"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = exports.handleRegister = void 0;
const jwt_1 = require("./utils/jwt");
const password_1 = require("./utils/password");
const dynamodb_1 = require("./utils/dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const google_verify_1 = require("./utils/google-verify");
const email_1 = require("./utils/email");
const validation_1 = require("./utils/validation");
const uuid_1 = require("uuid");
// Respuesta estándar
const createResponse = (statusCode, body, headers = {}) => ({
    statusCode,
    headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
        ...headers,
    },
    body: JSON.stringify(body),
});
// Manejo de errores
const handleError = (error) => {
    console.error('Error:', error);
    if (error.message.includes('Validation error')) {
        return createResponse(400, { error: error.message });
    }
    if (error.message.includes('User already exists') || error.message.includes('Invalid credentials')) {
        return createResponse(400, { error: error.message });
    }
    if (error.message.includes('Unauthorized') || error.message.includes('Token expired')) {
        return createResponse(401, { error: error.message });
    }
    if (error.message.includes('Not found')) {
        return createResponse(404, { error: error.message });
    }
    return createResponse(500, { error: 'Internal server error' });
};
// Email functions are now imported from ./utils/email
// 🔓 ENDPOINT: Registro manual
const handleRegister = async (event) => {
    try {
        console.log('Register event received:', JSON.stringify(event));
        if (!event.body) {
            return createResponse(400, { error: 'Request body is required' });
        }
        const { email, password, firstName, lastName, fullName, birthDate, gender, clientId } = JSON.parse(event.body);
        // Support both fullName and firstName/lastName
        const finalFullName = fullName || (firstName && lastName ? `${firstName} ${lastName}` : '');
        const finalFirstName = firstName || (fullName ? fullName.split(' ')[0] : '');
        const finalLastName = lastName || (fullName ? fullName.split(' ').slice(1).join(' ') : '');
        if (!email || !password || (!fullName && (!firstName || !lastName))) {
            return createResponse(400, {
                error: 'Email, password, and name (fullName or firstName/lastName) are required'
            });
        }
        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return createResponse(400, { error: 'Invalid email format' });
        }
        // Validate password strength
        if (password.length < 8) {
            return createResponse(400, {
                error: 'Password must be at least 8 characters long'
            });
        }
        // Validate birth date if provided
        if (birthDate) {
            const birthDateObj = new Date(birthDate);
            const today = new Date();
            const age = today.getFullYear() - birthDateObj.getFullYear();
            if (isNaN(birthDateObj.getTime())) {
                return createResponse(400, { error: 'Invalid birth date format. Use YYYY-MM-DD' });
            }
            if (age < 13) {
                return createResponse(400, { error: 'You must be at least 13 years old to register' });
            }
            if (age > 120) {
                return createResponse(400, { error: 'Invalid birth date' });
            }
        }
        // Validate gender if provided
        if (gender && !['male', 'female', 'prefer-not-to-say'].includes(gender)) {
            return createResponse(400, { error: 'Invalid gender value' });
        }
        // Check if user already exists
        const existingUser = await (0, dynamodb_1.getUserByEmail)(email);
        if (existingUser) {
            return createResponse(400, { error: 'User already exists' });
        }
        // Create new user
        const userId = (0, uuid_1.v4)();
        const hashedPassword = await (0, password_1.hashPassword)(password);
        const newUser = {
            userId,
            email,
            password: hashedPassword,
            firstName: finalFirstName,
            lastName: finalLastName,
            fullName: finalFullName,
            birthDate: birthDate || undefined,
            gender: gender || undefined,
            clientId: clientId || null,
            emailVerified: false,
            profileCompleted: !!birthDate && !!gender, // Profile completed if optional fields are provided
            provider: 'email',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        await (0, dynamodb_1.createUser)(newUser);
        // Generate email verification token
        const verificationToken = (0, uuid_1.v4)();
        const verificationExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
        await (0, dynamodb_1.createEmailVerification)({
            userId,
            email,
            token: verificationToken,
            expiresAt: verificationExpiry.getTime(),
            createdAt: new Date().toISOString()
        });
        console.log(`Email verification created for user ${userId} with token ${verificationToken}`);
        // Send verification email
        await (0, email_1.sendVerificationEmail)(email, verificationToken, finalFirstName);
        console.log(`Verification email sent to: ${email}`);
        return createResponse(201, {
            message: 'User registered successfully. Please check your email for verification.',
            userId
            // verificationToken removed for security in production
        });
    }
    catch (error) {
        console.error('Registration error:', error);
        return createResponse(500, { error: 'Internal server error' });
    }
};
exports.handleRegister = handleRegister;
// 🔓 ENDPOINT: Login manual
const handleLogin = async (event) => {
    try {
        const data = (0, validation_1.validateData)(validation_1.loginSchema, JSON.parse(event.body || '{}'));
        // Buscar usuario
        const user = await (0, dynamodb_1.getUserByEmail)(data.email);
        if (!user || !user.password) {
            throw new Error('Invalid credentials');
        }
        // Verificar password
        const isValidPassword = await (0, password_1.comparePassword)(data.password, user.password);
        if (!isValidPassword) {
            throw new Error('Invalid credentials');
        }
        // Crear sesión (permitir login incluso si email no está verificado)
        const sessionId = (0, uuid_1.v4)();
        // Generar tokens con el sessionId
        const tokens = await (0, jwt_1.generateTokens)(user.userId, user.email, sessionId);
        // Crear sesión en DynamoDB
        await (0, dynamodb_1.createSession)({
            sessionId,
            userId: user.userId,
            refreshToken: tokens.refreshToken,
            expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000, // 30 días en milisegundos
        });
        return createResponse(200, {
            message: 'Login successful',
            user: {
                userId: user.userId,
                email: user.email,
                firstName: user.firstName,
                lastName: user.lastName,
                profileCompleted: user.profileCompleted,
                emailVerified: user.emailVerified, // El frontend usará esto para determinar el flujo
            },
            tokens,
        });
    }
    catch (error) {
        return handleError(error);
    }
};
// 🔓 ENDPOINT: Google OAuth
const handleGoogleAuth = async (event) => {
    try {
        const data = (0, validation_1.validateData)(validation_1.googleAuthSchema, JSON.parse(event.body || '{}'));
        // Verificar Google ID token
        const googleUser = await (0, google_verify_1.verifyGoogleToken)(data.idToken);
        // Buscar usuario existente por Google ID o email
        let user = await (0, dynamodb_1.getUserByGoogleId)(googleUser.sub);
        if (!user) {
            user = await (0, dynamodb_1.getUserByEmail)(googleUser.email);
        }
        if (user) {
            // Usuario existente - actualizar Google ID si es necesario
            if (!user.googleId) {
                await (0, dynamodb_1.updateUser)(user.userId, { googleId: googleUser.sub });
                user.googleId = googleUser.sub;
            }
        }
        else {
            // Nuevo usuario - crear cuenta
            const userId = (0, uuid_1.v4)();
            user = await (0, dynamodb_1.createUser)({
                userId,
                email: googleUser.email,
                firstName: googleUser.given_name || '',
                lastName: googleUser.family_name || '',
                googleId: googleUser.sub,
                emailVerified: true, // Google ya verificó el email
                profileCompleted: false,
                provider: 'google',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
            });
        }
        // Crear sesión primero
        const sessionId = (0, uuid_1.v4)();
        // Generar tokens con el sessionId
        const tokens = await (0, jwt_1.generateTokens)(user.userId, user.email, sessionId);
        // Crear sesión en DynamoDB
        await (0, dynamodb_1.createSession)({
            sessionId,
            userId: user.userId,
            refreshToken: tokens.refreshToken,
            expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000, // 30 días en milisegundos
        });
        return createResponse(200, {
            message: 'Google authentication successful',
            user: {
                userId: user.userId,
                email: user.email,
                firstName: user.firstName,
                lastName: user.lastName,
                profileCompleted: user.profileCompleted,
                emailVerified: user.emailVerified,
            },
            tokens,
        });
    }
    catch (error) {
        return handleError(error);
    }
};
// 🔒 ENDPOINT: Completar perfil (protegido)
const handleCompleteProfile = async (event) => {
    try {
        const data = (0, validation_1.validateData)(validation_1.completeProfileSchema, JSON.parse(event.body || '{}'));
        const userId = event.requestContext.authorizer.userId;
        // Preparar actualizaciones del perfil
        const updates = {
            birthDate: data.birthDate.split('T')[0], // Solo YYYY-MM-DD, sin hora
            profileCompleted: true,
            // updatedAt se agrega automáticamente en updateUser()
        };
        // Agregar phone si se proporciona y no está vacío
        if (data.phone && data.phone.trim()) {
            updates.phone = data.phone;
        }
        // Agregar gender si se proporciona
        if (data.gender) {
            // Normalizar valores en español a inglés
            const genderMap = {
                'hombre': 'male',
                'mujer': 'female',
                'prefiero-no-decirlo': 'prefer-not-to-say'
            };
            updates.gender = genderMap[data.gender] || data.gender;
        }
        // Actualizar perfil del usuario
        await (0, dynamodb_1.updateUser)(userId, updates);
        // Obtener usuario actualizado
        const user = await (0, dynamodb_1.getUserById)(userId);
        if (!user) {
            throw new Error('User not found');
        }
        return createResponse(200, {
            message: 'Profile completed successfully',
            user: {
                userId: user.userId,
                email: user.email,
                firstName: user.firstName,
                lastName: user.lastName,
                phone: user.phone,
                birthDate: user.birthDate,
                gender: user.gender,
                profileCompleted: user.profileCompleted,
                emailVerified: user.emailVerified,
            },
        });
    }
    catch (error) {
        return handleError(error);
    }
};
// 🔒 ENDPOINT: Obtener perfil (protegido)
const handleGetProfile = async (event) => {
    try {
        const userId = event.requestContext.authorizer.userId;
        const user = await (0, dynamodb_1.getUserById)(userId);
        if (!user) {
            throw new Error('User not found');
        }
        return createResponse(200, {
            user: {
                userId: user.userId,
                email: user.email,
                firstName: user.firstName,
                lastName: user.lastName,
                phone: user.phone,
                birthDate: user.birthDate,
                profileCompleted: user.profileCompleted,
                emailVerified: user.emailVerified,
                provider: user.provider,
                createdAt: user.createdAt,
            },
        });
    }
    catch (error) {
        return handleError(error);
    }
};
// 🔒 ENDPOINT: Logout (protegido)
const handleLogout = async (event) => {
    try {
        const sessionId = event.requestContext.authorizer.sessionId;
        // Eliminar sesión correctamente usando SESSIONS_TABLE
        await dynamodb_1.docClient.send(new lib_dynamodb_1.DeleteCommand({
            TableName: dynamodb_1.SESSIONS_TABLE,
            Key: {
                PK: `SESSION#${sessionId}`,
                SK: 'SESSION'
            }
        }));
        return createResponse(200, {
            message: 'Logout successful',
        });
    }
    catch (error) {
        return handleError(error);
    }
};
// 🔓 ENDPOINT: Refresh token
const handleRefreshToken = async (event) => {
    try {
        const data = (0, validation_1.validateData)(validation_1.refreshTokenSchema, JSON.parse(event.body || '{}'));
        // Verificar refresh token
        const payload = await (0, jwt_1.verifyToken)(data.refreshToken, 'refresh');
        // Verificar sesión
        const session = await (0, dynamodb_1.getSession)(payload.sessionId);
        if (!session || session.refreshToken !== data.refreshToken) {
            throw new Error('Invalid refresh token');
        }
        // Generar nuevos tokens con el mismo sessionId
        const tokens = await (0, jwt_1.generateTokens)(session.userId, payload.email, session.sessionId);
        // Actualizar sesión con nuevo refresh token
        await (0, dynamodb_1.createSession)({
            sessionId: session.sessionId,
            userId: session.userId,
            refreshToken: tokens.refreshToken,
            expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000, // 30 días en milisegundos
        });
        return createResponse(200, {
            message: 'Tokens refreshed successfully',
            tokens,
        });
    }
    catch (error) {
        return handleError(error);
    }
};
// 🔓 ENDPOINT: Verificar email
const handleVerifyEmail = async (event) => {
    try {
        console.log('Verify email event received:', JSON.stringify(event));
        if (!event.body) {
            return createResponse(400, { error: 'Request body is required' });
        }
        const { token } = JSON.parse(event.body);
        console.log('Token received:', token);
        if (!token) {
            return createResponse(400, { error: 'Token is required' });
        }
        // Obtener verificación de email
        console.log('Getting email verification for token:', token);
        const verification = await (0, dynamodb_1.getEmailVerification)(token);
        console.log('Verification found:', verification);
        if (!verification) {
            return createResponse(400, { error: 'Invalid or expired verification token' });
        }
        // Verificar si no ha expirado
        console.log('Current time:', Date.now(), 'Expires at:', verification.expiresAt);
        if (verification.expiresAt < Date.now()) {
            await (0, dynamodb_1.deleteEmailVerification)(token);
            return createResponse(400, { error: 'Verification token has expired' });
        }
        // Marcar email como verificado
        console.log('Updating user:', verification.userId);
        await (0, dynamodb_1.updateUser)(verification.userId, {
            emailVerified: true,
        });
        // Eliminar token de verificación
        console.log('Deleting verification token');
        await (0, dynamodb_1.deleteEmailVerification)(token);
        return createResponse(200, {
            message: 'Email verified successfully',
        });
    }
    catch (error) {
        console.error('Verification error:', error);
        return createResponse(500, { error: 'Internal server error' });
    }
};
// 🔓 ENDPOINT: Forgot password
const handleForgotPassword = async (event) => {
    try {
        const data = (0, validation_1.validateData)(validation_1.forgotPasswordSchema, JSON.parse(event.body || '{}'));
        // Buscar usuario
        const user = await (0, dynamodb_1.getUserByEmail)(data.email);
        if (!user) {
            // Por seguridad, no revelar si el email existe o no
            return createResponse(200, {
                message: 'If an account with this email exists, you will receive a password reset link.',
            });
        }
        // Generar token de reset
        const resetToken = await (0, jwt_1.generatePasswordResetToken)(user.userId, user.email);
        // Enviar email con token
        await (0, email_1.sendPasswordResetEmail)(user.email, resetToken, user.firstName || 'Usuario');
        return createResponse(200, {
            message: 'If an account with this email exists, you will receive a password reset link.',
        });
    }
    catch (error) {
        return handleError(error);
    }
};
// 🔓 ENDPOINT: Reset password
const handleResetPassword = async (event) => {
    try {
        const data = (0, validation_1.validateData)(validation_1.resetPasswordSchema, JSON.parse(event.body || '{}'));
        // Verificar token de reset
        const payload = await (0, jwt_1.verifyPasswordResetToken)(data.token);
        // Hash de la nueva password
        const hashedPassword = await (0, password_1.hashPassword)(data.newPassword);
        // Actualizar password
        await (0, dynamodb_1.updateUser)(payload.userId, {
            password: hashedPassword,
            updatedAt: new Date().toISOString(),
        });
        return createResponse(200, {
            message: 'Password reset successfully',
        });
    }
    catch (error) {
        return handleError(error);
    }
};
// 🔒 ENDPOINT: Actualizar perfil (protegido)
const handleUpdateProfile = async (event) => {
    try {
        const data = (0, validation_1.validateData)(validation_1.updateProfileSchema, JSON.parse(event.body || '{}'));
        const userId = event.requestContext.authorizer.userId;
        // Actualizar solo los campos proporcionados
        const updateData = {
            updatedAt: new Date().toISOString(),
        };
        if (data.firstName)
            updateData.firstName = data.firstName;
        if (data.lastName)
            updateData.lastName = data.lastName;
        if (data.phone)
            updateData.phone = data.phone;
        if (data.birthDate)
            updateData.birthDate = data.birthDate;
        await (0, dynamodb_1.updateUser)(userId, updateData);
        // Obtener usuario actualizado
        const user = await (0, dynamodb_1.getUserById)(userId);
        if (!user) {
            throw new Error('User not found');
        }
        return createResponse(200, {
            message: 'Profile updated successfully',
            user: {
                userId: user.userId,
                email: user.email,
                firstName: user.firstName,
                lastName: user.lastName,
                phone: user.phone,
                birthDate: user.birthDate,
                profileCompleted: user.profileCompleted,
                emailVerified: user.emailVerified,
            },
        });
    }
    catch (error) {
        return handleError(error);
    }
};
// Handler principal de Lambda
const handler = async (event, context) => {
    console.log('=== LAMBDA HANDLER STARTED ===');
    console.log('Lambda function name:', context.functionName);
    console.log('Lambda function version:', context.functionVersion);
    console.log('Event received:', JSON.stringify(event, null, 2));
    console.log('Environment variables:', JSON.stringify(process.env, null, 2));
    // CORS preflight
    if (event.httpMethod === 'OPTIONS') {
        console.log('Handling OPTIONS request');
        return createResponse(200, {}, {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,Authorization',
            'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
        });
    }
    const path = event.path;
    const method = event.httpMethod;
    try {
        // Rutas públicas (sin autenticación)
        if (method === 'POST' && path === '/auth/register') {
            return await (0, exports.handleRegister)(event);
        }
        if (method === 'POST' && path === '/auth/login') {
            return await handleLogin(event);
        }
        // Support both /auth/google and /auth/google-auth for backward compatibility
        if (method === 'POST' && (path === '/auth/google' || path === '/auth/google-auth')) {
            return await handleGoogleAuth(event);
        }
        if (method === 'POST' && path === '/auth/refresh') {
            return await handleRefreshToken(event);
        }
        if (method === 'POST' && path === '/auth/verify-email') {
            return await handleVerifyEmail(event);
        }
        if (method === 'POST' && path === '/auth/forgot-password') {
            return await handleForgotPassword(event);
        }
        if (method === 'POST' && path === '/auth/reset-password') {
            return await handleResetPassword(event);
        }
        // Rutas protegidas (requieren autenticación)
        // El JWT Authorizer ya validó el token y agregó el contexto del usuario
        const authorizedEvent = event;
        if (method === 'POST' && path === '/auth/complete-profile') {
            return await handleCompleteProfile(authorizedEvent);
        }
        if (method === 'GET' && path === '/auth/me') {
            return await handleGetProfile(authorizedEvent);
        }
        if (method === 'POST' && path === '/auth/logout') {
            return await handleLogout(authorizedEvent);
        }
        if (method === 'PUT' && path === '/auth/profile') {
            return await handleUpdateProfile(authorizedEvent);
        }
        // Ruta no encontrada
        return createResponse(404, { error: 'Route not found' });
    }
    catch (error) {
        return handleError(error);
    }
};
exports.handler = handler;
//# sourceMappingURL=index.js.map