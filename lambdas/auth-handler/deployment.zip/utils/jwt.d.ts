export interface JWTPayload {
    userId: string;
    email: string;
    role: string;
    sessionId: string;
}
export interface TokenPair {
    accessToken: string;
    refreshToken: string;
    expiresIn: number;
}
/**
 * Generate access token and refresh token
 */
export declare function generateTokens(userId: string, email?: string, sessionId?: string): Promise<TokenPair>;
/**
 * Verify and decode JWT token
 */
export declare function verifyToken(token: string, type?: 'access' | 'refresh'): Promise<any>;
export declare const generatePasswordResetToken: typeof generateResetToken;
export declare const verifyPasswordResetToken: typeof verifyResetToken;
/**
 * Generate password reset token
 */
export declare function generateResetToken(userId: string, email: string): Promise<string>;
/**
 * Verify password reset token
 */
export declare function verifyResetToken(token: string): Promise<{
    userId: string;
    email: string;
}>;
//# sourceMappingURL=jwt.d.ts.map