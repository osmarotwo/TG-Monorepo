"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateData = exports.updateProfileSchema = exports.resetPasswordSchema = exports.forgotPasswordSchema = exports.verifyEmailSchema = exports.refreshTokenSchema = exports.completeProfileSchema = exports.googleAuthSchema = exports.loginSchema = exports.registerSchema = void 0;
const joi_1 = __importDefault(require("joi"));
// Schemas de validación para todos los endpoints
exports.registerSchema = joi_1.default.object({
    email: joi_1.default.string().email().required(),
    password: joi_1.default.string().min(8).required(),
    firstName: joi_1.default.string().min(2).max(50).required(),
    lastName: joi_1.default.string().min(2).max(50).required(),
});
exports.loginSchema = joi_1.default.object({
    email: joi_1.default.string().email().required(),
    password: joi_1.default.string().required(),
});
exports.googleAuthSchema = joi_1.default.object({
    idToken: joi_1.default.string().required(),
});
exports.completeProfileSchema = joi_1.default.object({
    phone: joi_1.default.string().pattern(/^\+?[1-9]\d{1,14}$/).optional().allow(''),
    birthDate: joi_1.default.string().isoDate().required(), // Keep as string for DynamoDB
    gender: joi_1.default.string().valid('male', 'female', 'prefer-not-to-say', 'hombre', 'mujer', 'prefiero-no-decirlo').optional(),
    fullName: joi_1.default.string().optional(),
    email: joi_1.default.string().email().optional(),
    profileCompleted: joi_1.default.boolean().default(true),
});
exports.refreshTokenSchema = joi_1.default.object({
    refreshToken: joi_1.default.string().required(),
});
exports.verifyEmailSchema = joi_1.default.object({
    token: joi_1.default.string().required(),
});
exports.forgotPasswordSchema = joi_1.default.object({
    email: joi_1.default.string().email().required(),
});
exports.resetPasswordSchema = joi_1.default.object({
    token: joi_1.default.string().required(),
    newPassword: joi_1.default.string().min(8).required(),
});
exports.updateProfileSchema = joi_1.default.object({
    firstName: joi_1.default.string().min(2).max(50).optional(),
    lastName: joi_1.default.string().min(2).max(50).optional(),
    phone: joi_1.default.string().pattern(/^\+?[1-9]\d{1,14}$/).optional(),
    birthDate: joi_1.default.date().iso().max('now').optional(),
});
// Función auxiliar para validar datos
const validateData = (schema, data) => {
    const { error, value } = schema.validate(data, { abortEarly: false });
    if (error) {
        const errorMessage = error.details.map(detail => detail.message).join(', ');
        throw new Error(`Validation error: ${errorMessage}`);
    }
    return value;
};
exports.validateData = validateData;
//# sourceMappingURL=validation.js.map