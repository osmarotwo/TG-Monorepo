/**
 * Email Service - Manejo de envío de emails con AWS SES
 */
export interface EmailOptions {
    to: string;
    subject: string;
    htmlBody: string;
    textBody?: string;
}
/**
 * Send email using AWS SES
 */
export declare function sendEmail(options: EmailOptions): Promise<void>;
/**
 * Send verification email
 */
export declare function sendVerificationEmail(email: string, verificationToken: string, firstName: string): Promise<void>;
/**
 * Send password reset email
 */
export declare function sendPasswordResetEmail(email: string, resetToken: string, firstName: string): Promise<void>;
//# sourceMappingURL=email.d.ts.map