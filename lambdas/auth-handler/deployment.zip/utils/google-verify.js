"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyGoogleToken = verifyGoogleToken;
const google_auth_library_1 = require("google-auth-library");
const client_ssm_1 = require("@aws-sdk/client-ssm");
const ssmClient = new client_ssm_1.SSMClient({});
// Cache for Google Client ID
let googleClientIdCache = null;
let cacheExpiry = 0;
/**
 * Get Google Client ID from SSM Parameter Store with caching
 */
async function getGoogleClientId() {
    const now = Date.now();
    if (googleClientIdCache && now < cacheExpiry) {
        return googleClientIdCache;
    }
    try {
        const command = new client_ssm_1.GetParameterCommand({
            Name: '/auth/google-client-id',
            WithDecryption: false,
        });
        const response = await ssmClient.send(command);
        if (!response.Parameter?.Value) {
            throw new Error('Google Client ID not found in SSM');
        }
        googleClientIdCache = response.Parameter.Value;
        cacheExpiry = now + (10 * 60 * 1000); // Cache for 10 minutes
        return googleClientIdCache;
    }
    catch (error) {
        console.error('Error getting Google Client ID from SSM:', error);
        throw new Error('Failed to retrieve Google Client ID');
    }
}
/**
 * Verify Google ID token and extract user information
 */
async function verifyGoogleToken(idToken) {
    try {
        const clientId = await getGoogleClientId();
        const client = new google_auth_library_1.OAuth2Client(clientId);
        const ticket = await client.verifyIdToken({
            idToken: idToken,
            audience: clientId,
        });
        const payload = ticket.getPayload();
        if (!payload) {
            throw new Error('Invalid Google token payload');
        }
        // Validate required fields
        if (!payload.sub || !payload.email) {
            throw new Error('Missing required fields in Google token');
        }
        const userInfo = {
            sub: payload.sub,
            email: payload.email,
            email_verified: payload.email_verified || false,
            name: payload.name || '',
            picture: payload.picture || '',
            given_name: payload.given_name || '',
            family_name: payload.family_name || '',
            locale: payload.locale,
        };
        console.log('Google token verified successfully for user:', userInfo.email);
        return userInfo;
    }
    catch (error) {
        console.error('Error verifying Google token:', error);
        throw new Error('Invalid Google token');
    }
}
//# sourceMappingURL=google-verify.js.map