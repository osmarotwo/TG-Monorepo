export interface GoogleUserInfo {
    sub: string;
    email: string;
    email_verified: boolean;
    name: string;
    picture: string;
    given_name: string;
    family_name: string;
    locale?: string;
}
/**
 * Verify Google ID token and extract user information
 */
export declare function verifyGoogleToken(idToken: string): Promise<GoogleUserInfo>;
//# sourceMappingURL=google-verify.d.ts.map