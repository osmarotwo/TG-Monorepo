import Joi from 'joi';
export declare const registerSchema: Joi.ObjectSchema<any>;
export declare const loginSchema: Joi.ObjectSchema<any>;
export declare const googleAuthSchema: Joi.ObjectSchema<any>;
export declare const completeProfileSchema: Joi.ObjectSchema<any>;
export declare const refreshTokenSchema: Joi.ObjectSchema<any>;
export declare const verifyEmailSchema: Joi.ObjectSchema<any>;
export declare const forgotPasswordSchema: Joi.ObjectSchema<any>;
export declare const resetPasswordSchema: Joi.ObjectSchema<any>;
export declare const updateProfileSchema: Joi.ObjectSchema<any>;
export declare const validateData: (schema: Joi.ObjectSchema, data: any) => any;
export interface RegisterRequest {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
}
export interface LoginRequest {
    email: string;
    password: string;
}
export interface GoogleAuthRequest {
    idToken: string;
}
export interface CompleteProfileRequest {
    phone?: string;
    birthDate: string;
    gender?: string;
    fullName?: string;
    email?: string;
    profileCompleted?: boolean;
}
export interface RefreshTokenRequest {
    refreshToken: string;
}
export interface VerifyEmailRequest {
    token: string;
}
export interface ForgotPasswordRequest {
    email: string;
}
export interface ResetPasswordRequest {
    token: string;
    newPassword: string;
}
export interface UpdateProfileRequest {
    firstName?: string;
    lastName?: string;
    phone?: string;
    birthDate?: string;
}
//# sourceMappingURL=validation.d.ts.map